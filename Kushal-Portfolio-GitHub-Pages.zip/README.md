# Kushal's Portfolio

A responsive, professional student portfolio built with plain HTML, CSS, and JavaScript. It is designed for free hosting on GitHub Pages.

## Before publishing

1. **Add your profile photo:** replace `assets/profile-placeholder.svg` by adding your own photo as `assets/profile.jpg`.
2. In `index.html`, find:
   ```html
   <img src="assets/profile-placeholder.svg" alt="Placeholder for Kushal's profile photo" id="profile-photo">
   ```
   Replace it with:
   ```html
   <img src="assets/profile.jpg" alt="Kushal's profile photo" id="profile-photo">
   ```
3. Replace `YOUR_EMAIL@example.com` with the email address you want to publish. If you don't want to show an email, remove the email link.
4. Review the skills and remove any language or tool you have not studied yet.
5. The three project cards are **ideas only, not completed projects**. Build each one before presenting it as finished. Then update its status, description, and links.
6. Verify the university name, degree details, and any dates before publishing.

## Publish free with GitHub Pages

### Option A: Use the main profile website URL

This creates a website at `https://kushal-2006.github.io/`.

1. Sign in at [GitHub](https://github.com/) as `Kushal-2006`.
2. Create a **new public repository** named exactly `Kushal-2006.github.io`.
3. Upload the contents of this folder to the repository's **root**. `index.html` must be at the root, not inside another nested folder.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes, then visit `https://kushal-2006.github.io/`. GitHub Pages may take several minutes to publish the first time.

### Option B: Publish from a repository with another name

If the repository is called `portfolio`, enable Pages using the same settings above. The URL will usually be `https://kushal-2006.github.io/portfolio/`. Use the actual URL GitHub shows in Settings → Pages.

## Update your portfolio later

Edit `index.html` to update content and `styles.css` to change the design. Upload the changed files to the same GitHub repository. GitHub Pages automatically republishes the site after changes.

## Notes

- Hosting is free with GitHub Pages for a public repository.
- No build tools or paid domain are required.
- The site uses Google Fonts when an internet connection is available; system fonts will be used if they are not.
- Only publish contact details you are comfortable making public.
